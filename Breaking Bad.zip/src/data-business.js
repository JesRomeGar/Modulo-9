function getCharacters() {
return fetch("https://www.breakingbadapi.com/api/characters")
.then(response => {
    return response.json();
});
}


function getCharactersById(id) {
return fetch("https://www.breakingbadapi.com/api/characters/" + id)
.then(response => {
    return response.json();
});
}

export { getCharacters, getCharactersById };